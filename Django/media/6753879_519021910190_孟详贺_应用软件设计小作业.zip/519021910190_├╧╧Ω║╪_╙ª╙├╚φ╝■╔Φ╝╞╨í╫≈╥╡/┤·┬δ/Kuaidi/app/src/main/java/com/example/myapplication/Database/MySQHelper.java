package com.example.myapplication.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MySQHelper extends SQLiteOpenHelper {
    private static Integer Version = 1;


    public MySQHelper(Context context, String name, SQLiteDatabase.CursorFactory factory,
                      int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table User(" +
                "id integer primary key autoincrement," +
                "name varhar(8)," +
                "dizhi varhar(8)," +
                "shouji varhar(8)," +
                "password varchar(8))");
        sqLiteDatabase.execSQL("create table Kuaidi(" +
                "id integer primary key autoincrement," +
                "danhao varchar(8)," +
                "shoujianren varchar(8)," +
                "songjianren varchar(8)," +
                "qujianma varchar(4)," +
                "dizhi varhar(8)," +
                "shouji varhar(8)," +
                "songda varhar(8))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int c) {

    }
}
