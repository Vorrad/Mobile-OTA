package com.example.myapplication.Database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.KuaidiBean;

import java.util.ArrayList;
import java.util.List;


public class SqDao {
    private MySQHelper sqHelper;
    private List<KuaidiBean> list;
    private KuaidiBean kuaidiBean;
    public SqDao(Context context) {
        sqHelper = new MySQHelper(context, "table.db", null, 1);
    }
    public long UserAdd(String name, String password,String phone,String address) {
        SQLiteDatabase sqLiteDatabase = sqHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("dizhi", address);
        contentValues.put("password", password);
        contentValues.put("shouji", phone);
        long Check = sqLiteDatabase.insert("User", null, contentValues);
        sqLiteDatabase.close();
        return Check;
    }
    public long UpdateUser(String name, String password,String phone,String address){
        SQLiteDatabase sqLiteDatabase = sqHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("dizhi", address);
        contentValues.put("password", password);
        contentValues.put("shouji", password);
        long Check = sqLiteDatabase.update("User",contentValues,"name = ?",new String[]{name});
        sqLiteDatabase.close();
        return Check;
    }
    @SuppressLint("Range")
    public String QueryName(String name) {
        SQLiteDatabase sqLiteDatabase = sqHelper.getReadableDatabase();
        String sqll = "select name from User where name =" + "'" + name + "'";
        String nam = null;
        Cursor cursor = sqLiteDatabase.rawQuery(sqll, null);
        if (cursor.moveToNext()) {
            nam = cursor.getString(cursor.getColumnIndex("name"));
        }
        return nam;
    }
    @SuppressLint("Range")
    public String Querypassword(String name) {
        SQLiteDatabase sqLiteDatabase = sqHelper.getReadableDatabase();
        String sqll = "select password from User where name =" + "'" + name + "'";
        String mima = null;
        Cursor cursor = sqLiteDatabase.rawQuery(sqll, null);
        if (cursor.moveToNext()) {
            mima = cursor.getString(cursor.getColumnIndex("password"));
        }
        return mima;
    }
    public long RecordAdd(String shoujianren, String danhao,String qujianma,String songda,String songjianren,String dizhi,String shouji) {
        SQLiteDatabase sqLiteDatabase = sqHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("danhao", danhao);
        contentValues.put("shoujianren", shoujianren);
        contentValues.put("songjianren", songjianren);
        contentValues.put("qujianma", qujianma);
        contentValues.put("dizhi", dizhi);
        contentValues.put("shouji", shouji);
        contentValues.put("songda", songda);
        long Check = sqLiteDatabase.insert("Kuaidi", null, contentValues);
        sqLiteDatabase.close();
        return Check;
    }
    public List<KuaidiBean> QueryTime(){
        int sum = 0;
        list= new ArrayList<KuaidiBean>();
        SQLiteDatabase sqLiteDatabase = sqHelper.getReadableDatabase();
        String sql = "select Count(*) from Kuaidi";;
        Cursor cursor = sqLiteDatabase.rawQuery(sql,null);
        cursor.moveToFirst();
        sum = cursor.getInt(0);
        String sqll = "select * from Kuaidi";;
        String yue = null;
        String year = null;
        String day = null;
        String week = null;
        String beizhu = null;
        String nae = null;
        String leixing = null;
        String num =null ;
        int id = 0;
        Cursor cursor1 = sqLiteDatabase.rawQuery(sqll,null);
        for (int i = 1;i<= sum;i++) {
            if (cursor1.moveToNext()) {
                nae = cursor1.getString(cursor1.getColumnIndex("shoujianren"));
                year = cursor1.getString(cursor1.getColumnIndex("songjianren"));
                yue = cursor1.getString(cursor1.getColumnIndex("qujianma"));
                day = cursor1.getString(cursor1.getColumnIndex("dizhi"));
                week = cursor1.getString(cursor1.getColumnIndex("shouji"));
                num = cursor1.getString(cursor1.getColumnIndex("songda"));
                beizhu = cursor1.getString(cursor1.getColumnIndex("danhao"));
                id = cursor1.getInt(cursor1.getColumnIndex("id"));
                kuaidiBean= new KuaidiBean(nae,year,beizhu,yue,week,day,num,id);
                list.add(kuaidiBean);
            }
        }
        sqLiteDatabase.close();
        return list;
    }
    public List<KuaidiBean> QueryKuaidi(String name){
        int sum = 0;
        list= new ArrayList<KuaidiBean>();
        SQLiteDatabase sqLiteDatabase = sqHelper.getReadableDatabase();
        String sql = "select Count(*) from Kuaidi where shoujianren = '"+name+"'";
        Cursor cursor = sqLiteDatabase.rawQuery(sql,null);
        cursor.moveToFirst();
        sum = cursor.getInt(0);
        String sqll = "select * from Kuaidi where shoujianren = '"+name+"'";
        String yue = null;
        String year = null;
        String day = null;
        String week = null;
        String beizhu = null;
        String nae = null;
        String leixing = null;
        String num =null ;
        int id = 0;
        Cursor cursor1 = sqLiteDatabase.rawQuery(sqll,null);
        for (int i = 1;i<= sum;i++) {
            if (cursor1.moveToNext()) {
                nae = cursor1.getString(cursor1.getColumnIndex("shoujianren"));
                year = cursor1.getString(cursor1.getColumnIndex("songjianren"));
                yue = cursor1.getString(cursor1.getColumnIndex("qujianma"));
                day = cursor1.getString(cursor1.getColumnIndex("dizhi"));
                week = cursor1.getString(cursor1.getColumnIndex("shouji"));
                num = cursor1.getString(cursor1.getColumnIndex("songda"));
                beizhu = cursor1.getString(cursor1.getColumnIndex("danhao"));
                id = cursor1.getInt(cursor1.getColumnIndex("id"));
                kuaidiBean= new KuaidiBean(nae,year,beizhu,yue,week,day,num,id);
                list.add(kuaidiBean);
            }
        }
        sqLiteDatabase.close();
        return list;
    }
    public long KuaidiUp(int id,String songjianren) {
        SQLiteDatabase sqLiteDatabase = sqHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("songjianren", songjianren);
        contentValues.put("songda", "是");
        long check = sqLiteDatabase.update("Kuaidi",contentValues,"id = ?",new String[]{String.valueOf(id)});
        sqLiteDatabase.close();
        return check;
    }
}
