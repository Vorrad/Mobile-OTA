package com.example.myapplication.Fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import com.example.myapplication.Database.SqDao;
import com.example.myapplication.KuaidiAdapter;
import com.example.myapplication.R;

public class wode extends Fragment {
    private AlertDialog.Builder builder;
    private SqDao sqDao;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private ListView listView;
    private KuaidiAdapter kuaidiAdapter;
    private Button button;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_wode, container, false);
        listView = view.findViewById(R.id.listview_kuaidi);
        button = view.findViewById(R.id.refresh);
        sharedPreferences = getActivity().getSharedPreferences("SP", Context.MODE_PRIVATE);
        sqDao = new SqDao(getContext());
        kuaidiAdapter = new KuaidiAdapter(getContext(),sqDao.QueryKuaidi(sharedPreferences.getString("name","")));
        listView.setAdapter(kuaidiAdapter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                kuaidiAdapter = new KuaidiAdapter(getContext(),sqDao.QueryKuaidi(sharedPreferences.getString("name","")));
                listView.setAdapter(kuaidiAdapter);
            }
        });
        return view;
    }
}