package com.example.myapplication.Fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.Database.SqDao;
import com.example.myapplication.KuaidiAdapter;
import com.example.myapplication.KuaidiBean;
import com.example.myapplication.MainActivity;
import com.example.myapplication.R;

import java.util.List;


public class zhuye extends Fragment {
private AlertDialog.Builder builder;
private Button button;
private SqDao sqDao;
private SharedPreferences sharedPreferences;
private SharedPreferences.Editor editor;
private ListView listView;
private KuaidiAdapter kuaidiAdapter;
private List<KuaidiBean> list;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_zhuye, container, false);
        button = view.findViewById(R.id.add_kuaidi);
        listView = view.findViewById(R.id.listview_kuaidi);
        sharedPreferences = getActivity().getSharedPreferences("SP", Context.MODE_PRIVATE);
        sqDao = new SqDao(getContext());
        list = sqDao.QueryTime();
        kuaidiAdapter = new KuaidiAdapter(getContext(),list);
        listView.setAdapter(kuaidiAdapter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new MainActivity().i ==0){
                    Toast.makeText(getActivity(),"请先登录",Toast.LENGTH_SHORT).show();
                }else {
                    showMyStyle();
                }

            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (new MainActivity().i ==0){
                    Toast.makeText(getActivity(),"请先登录",Toast.LENGTH_SHORT).show();
                }else {
                    showTwo(list.get(list.size() - i - 1).getId());
                    Log.e("ssss",String.valueOf(list.size() - i - 1));
                }
            }
        });
        return view;
    }
    private void showMyStyle() {
        @SuppressLint("InflateParams") View view = LayoutInflater.from(getContext()).inflate(R.layout.activity_add_kuaidi, null);
        final EditText etUsername = view.findViewById(R.id.add_shiwu_place);
        final EditText etPassword = view.findViewById(R.id.add_shiwu_phone);

        builder = new AlertDialog.Builder(getContext()).setView(view).setTitle("发布快递信息").setIcon(R.drawable.kuaidi)
                .setPositiveButton("发布", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(sqDao.RecordAdd(sharedPreferences.getString("name",""),etUsername.getText().toString(),etPassword.getText().toString(),"否","无人",sharedPreferences.getString("address",""),sharedPreferences.getString("phone",""))==-1){
                            Toast.makeText(getActivity(),"发送失败",Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(getActivity(),"发送成功",Toast.LENGTH_SHORT).show();
                            kuaidiAdapter = new KuaidiAdapter(getContext(),sqDao.QueryTime());
                            listView.setAdapter(kuaidiAdapter);
                        }
                    }
                });

        builder.create().show();
    }
    private void showTwo(int j) {

        builder = new AlertDialog.Builder(getContext()).setIcon(R.mipmap.ic_launcher).setTitle("是否接单")
                .setMessage("派送快递").setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (new SqDao(getContext()).KuaidiUp(j,sharedPreferences.getString("name",""))==-1){
                            Toast.makeText(getContext(),"接单失败",Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getContext(),"接单成功",Toast.LENGTH_SHORT).show();
                            kuaidiAdapter = new KuaidiAdapter(getContext(),sqDao.QueryTime());
                            listView.setAdapter(kuaidiAdapter);
                        }

                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {


                        dialogInterface.dismiss();
                    }
                });
        builder.create().show();
    }
}