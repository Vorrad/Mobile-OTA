package com.example.myapplication;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.List;

public class KuaidiAdapter extends BaseAdapter {
    private List<KuaidiBean> mList;
    private LayoutInflater layoutInflater;

    public KuaidiAdapter (Context context, List<KuaidiBean> list){
        mList = list;
        layoutInflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return mList.size() ;
    }

    @Override
    public Object getItem(int i) {
        return mList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }


    public View getView(int j, View view, ViewGroup viewGroup) {
        int i = mList.size()-j-1;
        ViewHolder viewHolder;
        if (view == null) {
            viewHolder = new ViewHolder();
            view = layoutInflater.inflate(R.layout.listview, null);
            viewHolder.textView = (TextView)view.findViewById(R.id.shiwu_name);
            viewHolder.textView1 = (TextView) view.findViewById(R.id.shiwu_time);
            viewHolder.textView2 = (TextView)view.findViewById(R.id.shiwu_intro);
            viewHolder.textView3 = (TextView) view.findViewById(R.id.phone);
            viewHolder.textView4 = (TextView) view.findViewById(R.id.place);
            viewHolder.textView5 = (TextView) view.findViewById(R.id.shiwu_dizhi);
            viewHolder.textView6 = (TextView) view.findViewById(R.id.songjianren);
            //viewHolder.imageView = (ImageView)view.findViewById(R.id.shiwu_icon);
            view.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.textView.setText("收件人:"+mList.get(i).getShoujianren());
        viewHolder.textView1.setText("电话:"+mList.get(i).getShouji());
        viewHolder.textView2.setText("快递单号:"+mList.get(i).getDanhao());
        viewHolder.textView3.setText("取件码:"+mList.get(i).getShoujianma());
        viewHolder.textView4.setText("是否派送:"+mList.get(i).getPaisong());
        viewHolder.textView5.setText("地址:"+mList.get(i).getDizhi());
        viewHolder.textView6.setText("送件人:"+mList.get(i).getSongjianren());
      //  viewHolder.imageView.setImageURI(Uri.fromFile(new File(mList.get(i).getIcon())));
        return view;
    }
    public final class ViewHolder {
        public TextView textView, textView1, textView2, textView3,textView4,textView5,textView6;
        public ImageView imageView;
    }
}
