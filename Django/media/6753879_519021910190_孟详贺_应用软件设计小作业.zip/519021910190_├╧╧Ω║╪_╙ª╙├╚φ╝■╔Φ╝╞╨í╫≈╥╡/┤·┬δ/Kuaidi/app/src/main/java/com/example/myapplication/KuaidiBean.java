package com.example.myapplication;

public class KuaidiBean {
    private String shoujianren;
    private String songjianren;
    private String danhao;
    private String shoujianma;
    private String shouji;
    private String dizhi;
    private String paisong;
    private int id;

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public KuaidiBean(String shoujianren, String songjianren, String danhao, String shoujianma, String shouji, String dizhi, String paisong,int id){
        this.shoujianren = shoujianren;
        this.songjianren = songjianren;
        this.danhao = danhao;
        this.shoujianma = shoujianma;
        this.shouji = shouji;
        this.dizhi = dizhi;
        this.paisong = paisong;
        this.id = id;
    }
    public String getDanhao() {
        return danhao;
    }



    public String getPaisong() {
        return paisong;
    }


    public String getShoujianma() {
        return shoujianma;
    }

    public String getShoujianren() {
        return shoujianren;
    }

    public String getSongjianren() {
        return songjianren;
    }

    public void setDanhao(String danhao) {
        this.danhao = danhao;
    }


    public void setPaisong(String paisong) {
        this.paisong = paisong;
    }

    public void setShouji(String shouji) {
        this.shouji = shouji;
    }

    public String getShouji() {
        return shouji;
    }

    public void setDizhi(String dizhi) {
        this.dizhi = dizhi;
    }

    public String getDizhi() {
        return dizhi;
    }

    public void setShoujianma(String shoujianma) {
        this.shoujianma = shoujianma;
    }

    public void setShoujianren(String shoujianren) {
        this.shoujianren = shoujianren;
    }

    public void setSongjianren(String songjianren) {
        this.songjianren = songjianren;
    }
}
