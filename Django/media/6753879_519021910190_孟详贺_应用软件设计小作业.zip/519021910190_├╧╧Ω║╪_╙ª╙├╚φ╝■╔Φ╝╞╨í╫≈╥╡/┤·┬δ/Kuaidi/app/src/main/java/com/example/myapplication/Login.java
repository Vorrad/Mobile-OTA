package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Database.SqDao;

public class Login extends AppCompatActivity implements View.OnClickListener {
    private EditText et_name,et_password;
    private Button button;
    private String name,password;
    private SqDao sqDao;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private String admin,pass,user;
    private RadioGroup radioGroup;
    private TextView textView;
    private int oo = 0;
    private RadioButton radioButton,radioButton1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();
        button.setOnClickListener(this);
        textView.setOnClickListener(this);
    }
    public void initView(){
        et_name = findViewById(R.id.login_name);
        et_password = findViewById(R.id.login_password);
        button = findViewById(R.id.login_button);
        textView = findViewById(R.id.tv_register);
        sqDao = new SqDao(getApplicationContext());
        sharedPreferences = getSharedPreferences("SP",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        user = "null";
    }

    @Override
    public void onClick(View view) {

        name = et_name.getText().toString();
        password = et_password.getText().toString();
        switch (view.getId()) {
            case R.id.login_button:
                if ((name.isEmpty()) || (password.isEmpty())) {
                    Toast.makeText(getApplicationContext(), "请输入完整信息", Toast.LENGTH_SHORT).show();
                } else {

                    if (name.equals(sqDao.QueryName(name))) {
                        if (password.equals(sqDao.Querypassword(name))) {
                            Toast.makeText(getApplicationContext(), "登录成功", Toast.LENGTH_SHORT).show();
                            new MainActivity().i = 1;
                            SetSP(name, password,sharedPreferences.getString("phone",""),sharedPreferences.getString("address",""));
                            Intent intent = new Intent();
                            intent.setClass(Login.this, MainActivity.class);
                            this.startActivity(intent);
                        } else {
                            Toast.makeText(getApplicationContext(), "密码错误", Toast.LENGTH_SHORT).show();
                        }
                    } else{
                            Toast.makeText(getApplicationContext(), "请先注册", Toast.LENGTH_SHORT).show();
                        }
                    }
                break;
            case R.id.tv_register:
                Intent intent = new Intent();
                intent.setClass(Login.this, Register.class);
                this.startActivity(intent);
                this.finish();
                break;
        }
    }
    public void SetSP(String name,String password,String phone,String address){
        editor.putString("name",name);
        editor.putString("password",password);
        editor.putString("phone",phone);
        editor.putString("address",address);
        editor.commit();
    }
}