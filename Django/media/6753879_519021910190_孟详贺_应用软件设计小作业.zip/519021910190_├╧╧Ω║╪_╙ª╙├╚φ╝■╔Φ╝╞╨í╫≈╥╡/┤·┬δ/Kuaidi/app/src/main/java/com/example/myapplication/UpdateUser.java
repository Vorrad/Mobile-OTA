package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.UiAutomation;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.Database.SqDao;

public class UpdateUser extends AppCompatActivity implements View.OnClickListener {
    private EditText Et_name,Et_password,Et_pass,Et_xuehao,Et_phone;
    private Button bt_register;
    private String name,password,pass,xuehao,phone,email;
    private SqDao sqDao;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user);
        initView();
        bt_register.setOnClickListener(this);
    }
    public void initView(){
        Et_name = findViewById(R.id.register_name);
        Et_password = findViewById(R.id.register_password);
        Et_pass = findViewById(R.id.register_pass);
        bt_register = findViewById(R.id.register_button);
        Et_phone = findViewById(R.id.register_phone);
        Et_phone.setInputType(InputType.TYPE_CLASS_PHONE);//电话
        Et_xuehao = findViewById(R.id.register_xuehao);
        sqDao = new SqDao(getApplicationContext());
        sharedPreferences = getSharedPreferences("SP",MODE_PRIVATE);
        editor = sharedPreferences.edit();
        Et_name.setText(sharedPreferences.getString("name",""));
        Et_pass.setText(sharedPreferences.getString("password",""));
        Et_password.setText(sharedPreferences.getString("password",""));
        Et_phone.setText(sharedPreferences.getString("phone",""));
        Et_xuehao.setText(sharedPreferences.getString("address",""));
    }
    public void SetSP(String name,String password,String phone,String address){
        editor.putString("name",name);
        editor.putString("password",password);
        editor.putString("phone",phone);
        editor.putString("address",address);
        editor.commit();
    }
    @Override
    public void onClick(View view) {
        name = Et_name.getText().toString();
        password = Et_password.getText().toString();
        pass = Et_pass.getText().toString();
        xuehao = Et_xuehao.getText().toString();
        phone = Et_phone.getText().toString();
        if (phone.length() != 11){
            Toast.makeText(getApplicationContext(), "请输入正确的手机号", Toast.LENGTH_SHORT).show();
        }else {
            switch (view.getId()) {
                case R.id.register_button:
                    if ((name.isEmpty()) || (password.isEmpty()) || (pass.isEmpty()) || (xuehao.isEmpty()) || (phone.isEmpty())) {
                        Toast.makeText(getApplicationContext(), "请填写完整信息", Toast.LENGTH_SHORT).show();
                    } else if (password.equals(pass)) {
                        long add = sqDao.UpdateUser(name,password,phone,xuehao);
                        if (add == -1) {
                            Toast.makeText(getApplicationContext(), "修改失败", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "修改成功", Toast.LENGTH_SHORT).show();
                            SetSP(name,password,phone,xuehao);
                            Intent intent = new Intent();
                            intent.setClass(UpdateUser.this, Login.class);
                            this.startActivity(intent);
                            UpdateUser.this.finish();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "两次密码输入的不一致", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    }
}